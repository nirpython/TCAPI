from django.apps import AppConfig


class DataConfig(AppConfig):
    name = 'data'
